﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Chat
{
    public partial class FrmConversa : Form
    {
        Form1 mestre;
        string nome;

        public FrmConversa(Form1 m)
        {
            InitializeComponent();
            mestre = m;
            Random r = new Random();
            int id = r.Next(1, 10000);

            AtribuirNome($"Usuário {id}");
            txtNome.Text = $"Usuário {id}";


            btEnviar.Enabled = false;
        }

        void AtribuirNome(string n)
        {
            nome = n;
            Text = nome;
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
            AtribuirNome(txtNome.Text);
        }

        private void FrmConversa_FormClosing(object sender, FormClosingEventArgs e)
        {

            mestre.Fechar(this);
        }

        public void ReceberMensagem(string usuario, string texto)
        {

            if (usuario == nome)
            {
                txtHistorico.AppendText($"Você : {texto}{Environment.NewLine}");
            }
            else
            {
                txtHistorico.AppendText($"{usuario} : {texto}{Environment.NewLine}");
            }
        }


        private void txtMensagem_TextChanged(object sender, EventArgs e)
        {
            btEnviar.Enabled = !string.IsNullOrWhiteSpace(txtMensagem.Text);
        }


        private void btEnviar_Click(object sender, EventArgs e)
        {

            mestre.Disparar(nome, txtMensagem.Text);


            txtMensagem.Clear();
            txtMensagem.Focus();
        }

        private void txtMensagem_TextChanged_1(object sender, EventArgs e)
        {
            btEnviar.Enabled = !string.IsNullOrWhiteSpace(txtMensagem.Text);
        }
    }
}